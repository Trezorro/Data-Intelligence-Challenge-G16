# Very boring robot that does nothing:

from environment import RobotBase


def robot_epoch(robot: RobotBase):
    pass
