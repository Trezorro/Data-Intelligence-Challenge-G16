#%%
from tqdm import tqdm
from time import sleep
# %%
progress = tqdm(range(int(1000)),total=100)
for i in progress:
    progress.set_postfix(dict(i=i), refresh=False)
    sleep(0.001)
# %%
